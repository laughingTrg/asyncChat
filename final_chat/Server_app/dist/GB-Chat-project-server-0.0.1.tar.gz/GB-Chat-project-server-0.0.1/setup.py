from setuptools import setup, find_packages


setup(
    name='GB-Chat-project-server',
    version="0.0.1",
    description="A Simple asinc chat server",
    author="Evgeniy Zubairov",
    author_email="laughinchrist@gmail.com",
    url="https://github.com/laughingTrg/asyncChat",
    packages=find_packages(),
)
