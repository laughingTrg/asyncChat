from src.core.get_app_arguments import get_app_arguments
from src.core.message_processor import MessageProcessor
from src.core.log_decorator import Log